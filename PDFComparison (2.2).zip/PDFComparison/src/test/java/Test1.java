import de.redsix.pdfcompare.PdfComparator;

public class Test1 {
    public static void main(String[] args) throws Exception {
        // Path for the original document
        String file1 = "C:\\Users\\10820896\\OneDrive - LTIMindtree\\Desktop\\Testing-Extra\\sample-1-data.pdf";
        // Path for the updated document
        String file2 = "C:\\Users\\10820896\\OneDrive - LTIMindtree\\Desktop\\Testing-Extra\\updated-data.pdf";
        // Path for the comparison result document
        String res = "C:\\Users\\10820896\\OneDrive - LTIMindtree\\Desktop\\Testing-Extra\\results\\new-updated-result";

        //Ignore file path
        String IgnoreFile = "C:\\Users\\10820896\\OneDrive - LTIMindtree\\Desktop\\Gladiator\\PDFComparison\\ignore.conf";
        
        // Perform PDF comparison and write result to the specified path
        new PdfComparator(file1, file2).withIgnore(IgnoreFile).compare().writeTo(res);
        
        boolean isEquals = new PdfComparator(file1, file2).withIgnore(IgnoreFile).compare().writeTo(res);
        System.out.println("Are PDF files similar : "+isEquals);
        System.out.println("PDF Comparision Successful! ");
    }
}
