package com.example.pdfcomparator.service;

import de.redsix.pdfcompare.PdfComparator;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@Service
public class PdfService {

    public String comparePDFs(MultipartFile file1, MultipartFile file2) throws IOException {
        // Save uploaded files to temp files
        File tempFile1 = File.createTempFile("pdf1-", ".pdf");
        File tempFile2 = File.createTempFile("pdf2-", ".pdf");

        file1.transferTo(tempFile1);
        file2.transferTo(tempFile2);

        // Define output directory on Desktop
        String outputDirPath = System.getProperty("user.home") + "/OneDrive/Desktop/TestResult";
        File outputDir = new File(outputDirPath);

        // Create the directory if it doesn't exist
        if (!outputDir.exists()) {
            boolean created = outputDir.mkdirs();
            if (!created) {
                throw new IOException("Failed to create output directory: " + outputDirPath);
            }
        }

        // Final output path
        String outputPath = outputDirPath + "/pdf-comparison-result";

        // Perform comparison and write result
        boolean isEqual = new PdfComparator(tempFile1.getAbsolutePath(), tempFile2.getAbsolutePath())
                .compare()
                .writeTo(outputPath);

        // Return message
        return isEqual
                ? "✅ PDFs are identical."
                : "❌ PDFs differ. Output saved at: " + outputPath;
    }
}
