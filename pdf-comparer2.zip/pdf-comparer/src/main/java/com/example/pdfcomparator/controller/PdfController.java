package com.example.pdfcomparator.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.pdfcomparator.service.PdfService;

import java.io.IOException;

@Controller
public class PdfController {

    @Autowired
    private PdfService pdfService;

    @GetMapping("/")
    public String index() {
        return "index"; // should load index.html
    }


    @PostMapping("/compare")
    public String comparePDFs(@RequestParam("file1") MultipartFile file1,
                              @RequestParam("file2") MultipartFile file2,
                              Model model) throws IOException {
        String result = pdfService.comparePDFs(file1, file2);
        model.addAttribute("result", result);
        return "index"; // This will render index.html from templates
    }

}
